:orphan:

==========
pip-search
==========

Description
***********

.. pip-command-description:: search

Usage
*****

.. pip-command-usage:: search

Options
*******

.. pip-command-options:: search
