:mod:`encryption_options` -- Support for automatic client side encryption
=========================================================================

.. automodule:: pymongo.encryption_options
   :synopsis: Support for automatic client side encryption

   .. autoclass:: pymongo.encryption_options.AutoEncryptionOpts
      :members:
