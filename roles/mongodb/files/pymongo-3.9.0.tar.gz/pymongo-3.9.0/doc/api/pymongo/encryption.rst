:mod:`encryption` -- Client side encryption
===========================================

.. automodule:: pymongo.encryption
   :members:
