:mod:`json_util` -- Tools for using Python's :mod:`json` module with BSON documents
===================================================================================
.. automodule:: bson.json_util
   :synopsis: Tools for using Python's json module with BSON documents
   :members:
   :undoc-members:
   :member-order: bysource
